package com.practice.demo.service;

import org.springframework.data.jpa.repository.JpaRepository;

import com.practice.demo.dao.User;

public interface UserRepository extends JpaRepository<User, Long> {

	User findUserByUsername(String username);
}
