package com.hibernate_practice.DemoHib;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;
import org.hibernate.service.ServiceRegistryBuilder;

/**
 * Hello world!
 *
 */
public class App 
{
	
    public static void main( String[] args )
    {
		/*
		 * AlienName an=new AlienName(); an.setF_name("Simran"); an.setM_name("kaur");
		 * an.setL_name("Sethi");
		 */
        Alien a1=new Alien();
		/*
		 * sim.setId(102); sim.setName("Dim"); sim.setColor("Pink");
		 */
        Configuration con=new Configuration().configure().addAnnotatedClass(Alien.class);
        ServiceRegistry reg=new ServiceRegistryBuilder().applySettings(con.getProperties()).buildServiceRegistry();
        SessionFactory sf=con.buildSessionFactory(reg);
        
        Session session1=sf.openSession();
        session1.beginTransaction();
        
        a1=(Alien)session1.get(Alien.class, 101);
        session1.getTransaction().commit();
        
        session1.close();
        System.out.println(a1);
        
        Session session2=sf.openSession();
        session2.beginTransaction();
        a1=(Alien)session2.get(Alien.class, 101);
        session2.getTransaction().commit();       
        session2.close();
        System.out.println(a1);
    }
}
