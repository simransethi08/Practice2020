package com.recruitify.main;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecruiteeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecruiteeApplication.class, args);
	}

}
