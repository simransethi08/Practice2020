package com.recruitify.main.model;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Table(name = "address")
@Entity
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@Enumerated(EnumType.STRING)
	private AddressType address_type;
	private String address;
	private String city;
	private String country;
	private String state;
	private String landline;
	private String mobile1;
	private String mobile2;

	public Address(int id, AddressType address_type, String address, String city, String country, String state,
			String landline, String mobile1, String mobile2) {
		super();
		this.id = id;
		this.address_type = address_type;
		this.address = address;
		this.city = city;
		this.country = country;
		this.state = state;
		this.landline = landline;
		this.mobile1 = mobile1;
		this.mobile2 = mobile2;
	}


	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Column(name = "address_type", nullable = false)
	public AddressType getAddress_type() {
		return address_type;
	}

	public void setAddress_type(AddressType address_type) {
		this.address_type = address_type;
	}

	@Column(name = "address_value", nullable = false)
	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Column(name = "city", nullable = false)
	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	@Column(name = "country", nullable = false)
	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	@Column(name = "state", nullable = false)
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	@Column(name = "landline", nullable = true)
	public String getLandline() {
		return landline;
	}

	public void setLandline(String landline) {
		this.landline = landline;
	}

	@Column(name = "mob1", nullable = false)
	public String getMobile1() {
		return mobile1;
	}

	public void setMobile1(String mobile1) {
		this.mobile1 = mobile1;
	}

	@Column(name = "mob2", nullable = true)
	public String getMobile2() {
		return mobile2;
	}

	public void setMobile2(String mobile2) {
		this.mobile2 = mobile2;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + ((address_type == null) ? 0 : address_type.hashCode());
		result = prime * result + ((city == null) ? 0 : city.hashCode());
		result = prime * result + ((country == null) ? 0 : country.hashCode());
		result = prime * result + id;
		result = prime * result + ((landline == null) ? 0 : landline.hashCode());
		result = prime * result + ((mobile1 == null) ? 0 : mobile1.hashCode());
		result = prime * result + ((mobile2 == null) ? 0 : mobile2.hashCode());
		result = prime * result + ((state == null) ? 0 : state.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Address other = (Address) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (address_type != other.address_type)
			return false;
		if (city == null) {
			if (other.city != null)
				return false;
		} else if (!city.equals(other.city))
			return false;
		if (country == null) {
			if (other.country != null)
				return false;
		} else if (!country.equals(other.country))
			return false;
		if (id != other.id)
			return false;
		if (landline == null) {
			if (other.landline != null)
				return false;
		} else if (!landline.equals(other.landline))
			return false;
		if (mobile1 == null) {
			if (other.mobile1 != null)
				return false;
		} else if (!mobile1.equals(other.mobile1))
			return false;
		if (mobile2 == null) {
			if (other.mobile2 != null)
				return false;
		} else if (!mobile2.equals(other.mobile2))
			return false;
		if (state == null) {
			if (other.state != null)
				return false;
		} else if (!state.equals(other.state))
			return false;
		return true;
	}

}
