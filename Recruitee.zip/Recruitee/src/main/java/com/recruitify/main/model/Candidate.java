package com.recruitify.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "candidate_details")
public class Candidate {

	@GeneratedValue(strategy = GenerationType.AUTO)
	@Id
	private int id;
	private String first_name;
	private String middle_name;
	private String last_name;
	private String gender;
	private String marital_status;
	private String dob;

	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
	private Address perm_cnct_info;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "id")
	private Address temp_cnct_info;
	@Enumerated(EnumType.STRING)
	private JobType job_type;
	@Enumerated(EnumType.STRING)
	private EmploymentType emp_type;
	private int physically_chalngd;
	private String physically_chalngd_desc;

	public Candidate(int id, String first_name, String middle_name, String last_name, String gender,
			String marital_status, String dob, Address perm_cnct_info, Address temp_cnct_info, JobType job_type,
			EmploymentType emp_type, int physically_chalngd, String physically_chalngd_desc) {
		super();
		this.id = id;
		this.first_name = first_name;
		this.middle_name = middle_name;
		this.last_name = last_name;
		this.gender = gender;
		this.marital_status = marital_status;
		this.dob = dob;
		this.perm_cnct_info = perm_cnct_info;
		this.temp_cnct_info = temp_cnct_info;
		this.job_type = job_type;
		this.emp_type = emp_type;
		this.physically_chalngd = physically_chalngd;
		this.physically_chalngd_desc = physically_chalngd_desc;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getFirst_name() {
		return first_name;
	}

	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}

	public String getMiddle_name() {
		return middle_name;
	}

	public void setMiddle_name(String middle_name) {
		this.middle_name = middle_name;
	}

	public String getLast_name() {
		return last_name;
	}

	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getMarital_status() {
		return marital_status;
	}

	public void setMarital_status(String marital_status) {
		this.marital_status = marital_status;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	public Address getPerm_cnct_info() {
		return perm_cnct_info;
	}

	public void setPerm_cnct_info(Address perm_cnct_info) {
		this.perm_cnct_info = perm_cnct_info;
	}

	public Address getTemp_cnct_info() {
		return temp_cnct_info;
	}

	public void setTemp_cnct_info(Address temp_cnct_info) {
		this.temp_cnct_info = temp_cnct_info;
	}

	public JobType getJob_type() {
		return job_type;
	}

	public void setJob_type(JobType job_type) {
		this.job_type = job_type;
	}

	public EmploymentType getEmp_type() {
		return emp_type;
	}

	public void setEmp_type(EmploymentType emp_type) {
		this.emp_type = emp_type;
	}

	public int getPhysically_chalngd() {
		return physically_chalngd;
	}

	public void setPhysically_chalngd(int physically_chalngd) {
		this.physically_chalngd = physically_chalngd;
	}

	public String getPhysically_chalngd_desc() {
		return physically_chalngd_desc;
	}

	public void setPhysically_chalngd_desc(String physically_chalngd_desc) {
		this.physically_chalngd_desc = physically_chalngd_desc;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dob == null) ? 0 : dob.hashCode());
		result = prime * result + ((emp_type == null) ? 0 : emp_type.hashCode());
		result = prime * result + ((first_name == null) ? 0 : first_name.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + id;
		result = prime * result + ((job_type == null) ? 0 : job_type.hashCode());
		result = prime * result + ((last_name == null) ? 0 : last_name.hashCode());
		result = prime * result + ((marital_status == null) ? 0 : marital_status.hashCode());
		result = prime * result + ((middle_name == null) ? 0 : middle_name.hashCode());
		result = prime * result + ((perm_cnct_info == null) ? 0 : perm_cnct_info.hashCode());
		result = prime * result + physically_chalngd;
		result = prime * result + ((physically_chalngd_desc == null) ? 0 : physically_chalngd_desc.hashCode());
		result = prime * result + ((temp_cnct_info == null) ? 0 : temp_cnct_info.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Candidate other = (Candidate) obj;
		if (dob == null) {
			if (other.dob != null)
				return false;
		} else if (!dob.equals(other.dob))
			return false;
		if (emp_type != other.emp_type)
			return false;
		if (first_name == null) {
			if (other.first_name != null)
				return false;
		} else if (!first_name.equals(other.first_name))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (id != other.id)
			return false;
		if (job_type != other.job_type)
			return false;
		if (last_name == null) {
			if (other.last_name != null)
				return false;
		} else if (!last_name.equals(other.last_name))
			return false;
		if (marital_status == null) {
			if (other.marital_status != null)
				return false;
		} else if (!marital_status.equals(other.marital_status))
			return false;
		if (middle_name == null) {
			if (other.middle_name != null)
				return false;
		} else if (!middle_name.equals(other.middle_name))
			return false;
		if (perm_cnct_info == null) {
			if (other.perm_cnct_info != null)
				return false;
		} else if (!perm_cnct_info.equals(other.perm_cnct_info))
			return false;
		if (physically_chalngd != other.physically_chalngd)
			return false;
		if (physically_chalngd_desc == null) {
			if (other.physically_chalngd_desc != null)
				return false;
		} else if (!physically_chalngd_desc.equals(other.physically_chalngd_desc))
			return false;
		if (temp_cnct_info == null) {
			if (other.temp_cnct_info != null)
				return false;
		} else if (!temp_cnct_info.equals(other.temp_cnct_info))
			return false;
		return true;
	}

}
