package com.recruitify.main.model;

public enum EmploymentType {
Permanent,Temporary;
}
