package com.recruitify.main.model;

public enum JobType {
Walk_in,Internship,Hot_Vacancy;
}
