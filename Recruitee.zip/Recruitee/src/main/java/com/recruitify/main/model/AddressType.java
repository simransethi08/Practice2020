package com.recruitify.main.model;

public enum AddressType {
Temprory,Permanent;
}
