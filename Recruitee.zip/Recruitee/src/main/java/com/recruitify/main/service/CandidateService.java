package com.recruitify.main.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.recruitify.main.model.Candidate;
import com.recruitify.main.repository.CandidateRepository;

@Service
public class CandidateService {
	@Autowired
	CandidateRepository repo;

	public List<Candidate> getAllCandidates() {
		return repo.findAll();
	}

}
