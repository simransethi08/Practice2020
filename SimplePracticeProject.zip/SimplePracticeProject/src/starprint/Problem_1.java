package starprint;

public class Problem_1 {
	public static void lengthOfLastWord(String s) {
		if (s.length() == 0 || s.length() == -1 || s == null)
			throw new IllegalArgumentException("Invalid String");
		int len = 0;
		String s1 = s.trim();
		System.out.println(s1);
		for (int i = 0; i < s1.length(); i++) {
			if (s1.charAt(i) == ' ') {
				len = 0;
			} else {
				len++;
			}
		}
		System.out.println("The length of last word is:" + len);
	}

	public static int minMoves(int n, int startRow, int startCol, int endRow, int endCol) {
		// Write your code here
		int num = 0;
		if (startRow == endRow) {
			int rev = 0;
			if (endCol >= startCol) {
				rev = endCol - startCol;
			} else
				rev = startCol - endCol;
			if (rev % 2 != 0) {
				num = rev / 2 + 1;
			} else
				num = rev / 2;
		} else if ((startRow > endRow && startRow - endRow == 1) || (endRow > startRow && endRow - startRow == 1)) {
			int rev = 0;
			if (endCol >= startCol) {
				rev = endCol - startCol;
			} else
				rev = startCol - endCol;
			num = rev / 2;
		} else if (startCol == endCol) {
			int rev = 0;
			if (endRow >= startRow) {
				rev = endRow - startRow;
			} else
				rev = startRow - endRow;
			if (rev % 2 != 0) {
				num = rev / 2 + 1;
			} else
				num = rev / 2;
		} else if ((startCol > endCol && startCol - endCol == 1) || (endCol > startCol && endCol - startCol == 1)) {
			int rev = 0;
			if (endRow >= startRow) {
				rev = endRow - startRow;
			} else
				rev = startRow - endRow;
			num = rev / 2;
			System.out.println("4");
		} else {
			int row;
			row = Math.abs((endRow - startRow) / 2);
			// System.out.println(row);
			int col = Math.abs((endCol - startCol) / 2);
			// System.out.println(col);
			num = row + col;
		}

		return Math.abs(num);
	}
public static int $;
	static int howManyGames(int p, int d, int m, int s) {
		// Return the number of games you can buy
		String h_e;
		int count = 0;
		System.out.println($);
		if(s>p){
            s=s-p;
            count++;
        }else
        return count;
		while (s > 0) {
			if ((p-d) > m && s-p>0) {
				p = p - d;
				System.out.println("Hi");
				if(s-p<0) {
					return count;
				}
				s = s - p;
				count++;
			} else if(s-m>0){
				s = s - m;
				//System.out.println("Hello");
				count++;
			}else
				return count;
		}
		return count;
	}

	public static void main(String[] args) {
		//System.out.println(minMoves(6, 5, 1, 0, 5));
		//System.out.println(minMoves(7, 0, 3, 4, 3));
		System.out.println(howManyGames(100,19,1,180));

		// lengthOfLastWord("Simran Sethi");
	}
}
