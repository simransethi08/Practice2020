package starprint;

public class ArrayPattern_1 {
// 22. Print Pattern
	private static void print() {
		for (int i = 0; i < 4; i++) {
			for (int j = -1; j < i; j++) {
				System.out.print(i * 2 + 1);
			}
			System.out.println("");
		}
		for (int i = 3; i >= 0; --i) {
			for (int j = -1; j < i; ++j) {
				System.out.print(i * 2 + 1);
			}
			System.out.println("");
		}
	}

	public static void main(String[] args) {
		print();
	}
}
