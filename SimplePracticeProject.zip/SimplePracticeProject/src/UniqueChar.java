
public class UniqueChar {
// 4. Display number of unique characters in a string
	
	private static int countUniqueChar(String string) {
		String temp = "";
		for (int i = 0; i < string.length(); i++) {
			char current = string.charAt(i);
			if (temp.indexOf(current) < 0) {
				temp = temp + current;
			} else {
				temp = temp.replace(String.valueOf(current), "");
			}
		}

		return temp.toCharArray().length;
	}

	public static void main(String[] args) {
		
			int unique = countUniqueChar("abcabcdef");
			System.out.println("The number of uniques char are : " + unique);
		}
	
}
