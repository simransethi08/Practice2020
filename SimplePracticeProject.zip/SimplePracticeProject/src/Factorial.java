
public class Factorial {
	// 9. Factorial of number
	private static int findfactorial(int num) {
		// TODO Auto-generated method stub
		int fact = 1;
		for (int i = 1; i <= num; i++) {
			fact = fact * i;
		}
		return fact;
	}

	public static void main(String[] args) {
		if (args[0] != null) {
			int num = findfactorial(Integer.parseInt(args[0]));
			System.out.println("The factorial of given number is " + num);
		}
	}

}
