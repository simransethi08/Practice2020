public class StringSpaces {
	// 3. Find no of spaces in the given string
	public static int countSpaces(String str) {
		int spaceCount = 0;
		for (char c : str.toCharArray()) {
			if (c == ' ') {
				spaceCount++;
			}
		}
		return spaceCount;
	}

	public static void main(String[] args) {
		if (args[0] != null) {
			int count = countSpaces(args[0]);
			System.out.println("Numeric of spaces in string are : " + count);
		}
	}
}
