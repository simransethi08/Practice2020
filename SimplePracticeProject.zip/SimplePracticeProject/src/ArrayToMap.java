import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ArrayToMap {

	public Map<Integer, Integer> convertToMap(ArrayList<Integer> arr) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>(arr.size());
		int visited = -1;
		int count=0;
		
		for (int i = 0; i < arr.size(); i++) {
			visited = arr.get(i);
			if(map.containsKey(visited)==false)
			{
			count=1;
			for (int j = i + 1; j < arr.size(); j++) {
				
				int k=arr.get(j);
				if (visited==k) {
					count++;
				}	
			}
			map.put(visited,count);
			count=0;
			}

		}
		return map;
	}

	public Map<Integer, Integer> convertToMap2(ArrayList<Integer> arr) {
		Map<Integer, Integer> map = new HashMap<Integer, Integer>(arr.size());
		for (Integer i : arr) {
			Integer j = map.get(i);
			map.put(i, (j == null) ? 1 : j + 1);
		}
		return map;
	}
	public static void main(String[] args) {
		ArrayToMap atm=new ArrayToMap();
		ArrayList<Integer> arr=new ArrayList<Integer>();
		arr.add(1);
		arr.add(2);
		arr.add(1);
		arr.add(1);
		arr.add(5);
		arr.add(2);
		arr.add(1);
		arr.add(5);
		arr.add(6);

		System.out.println(atm.convertToMap2(arr));
	}
}
