import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Sol {
	 static int[] solve(int N, int M, int Q, String[] S, String[] quries) {
	        int[] count=new int[Q];
	        for(int i=0;i<Q;i++){
	            String p=quries[i].replace('?','.');
	            for(int j=0;j<N;j++) {
	            	Pattern r=Pattern.compile(p);
	            	Matcher m=r.matcher(S[j]);
	            	if(m.find()) {
	            		count[i]++;
	            	}
	            }
	            System.out.println(count[i]);
	            }
	        return count;
	        }
	 
	 
public static void main(String[] args) {
	String[] s= {"cat","map","bat","man","pen"};
	String[] q= {"?at","ma?","?a?","??n"};
	solve(5,3,4,s,q);
}
}
