package arrays;

import java.util.ArrayList;
import java.util.List;

public class SortArrayOneLoop {
	   public static int longestSubarray(List<Integer> arr) {
		    // Write your code here
		    List<Integer> result=new ArrayList<>();
		    for(int i=0;i+1<=arr.size();i++){
		    	if((arr.get(i)-arr.get(i+1)==1) ||(arr.get(i+1)-arr.get(i)==1)) {
		    		result.add(i);
		    	}
		    }

		    return result.size();

		    }
	   
	   public static int filledOrders(List<Integer> order, int k) {
		    // Write your code here
		    List<Integer> result=new ArrayList<>();
		    for(int i:order){
		    	System.out.println(i);
		        if(i>=k){
		            result.add(i);
		            k=k-i;
		        }
		    }
		    return result.size();
		    }

		

	public static void main(String[] args) {
		
		int[] arr = { 10, 12, 15, 1, 16, 18, 19, 31, 52, 6 };
		int[] arr2 = { 1,1,1,3,3,2,2 };
		int[] arr3= {5,6,7};

		List<Integer> result=new ArrayList<>();
		for(int i:arr2)
		{
			result.add(i);
		}
		System.out.println(longestSubarray(result));
		//System.out.println(filledOrders(result,3));
		
		for (int i = 1; i < arr.length; i++) {
			if (arr[i] < arr[i - 1]) {
				arr[i] = arr[i] + arr[i - 1];
				arr[i - 1] = arr[i] - arr[i - 1];
				arr[i] = arr[i] - arr[i - 1];
				i = 0;
			}
		}
		/*
		 * System.out.println("sorted Array :"); for (int i = 0; i < arr.length; i++) {
		 * System.out.println(arr[i] + " "); }
		 */

	}
}
