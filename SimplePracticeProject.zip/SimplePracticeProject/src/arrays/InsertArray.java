package arrays;

import java.util.Arrays;

public class InsertArray {
//20. Insert an element in an array at position = x, remaining elements should be pushed to the right

	private static int[] insertArray(int[] arr, int x, int val) {
		int[] newArr = new int[arr.length + 1];
		for (int i = 0; i < newArr.length; i++) {
			if (i < x - 1) {
				newArr[i] = arr[i];
			} else if (i == x - 1) {
				newArr[i] = val;
			} else
				newArr[i] = arr[i - 1];
		}
		return newArr;
	}

	public static void main(String[] args) {
		int[] arr = new int[args.length - 2];
		int pos = Integer.parseInt(args[0]);
		int val = Integer.parseInt(args[1]);
		int j = 0;
		for (int i = 2; i < args.length; i++) {
			arr[j] = Integer.parseInt(args[i]);
			j++;
		}
		System.out.println("The old array is " + Arrays.toString(arr));
		int[] num = insertArray(arr, pos, val);
		System.out.println("The new array is " + Arrays.toString(num));

		int[] my_array = { 25, 14, 56, 15, 36, 56, 77, 18, 29, 49 };

		// Insert an element in 3rd position of the array (index->2, value->5)

		// new code
		int Index_position = 2;
		int newValue = 5;

		System.out.println("Original Array : " + Arrays.toString(my_array));

		for (int i = my_array.length - 1; i > Index_position; i--) {
			my_array[i] = my_array[i - 1];
		}
		my_array[Index_position] = newValue;
		System.out.println("New Array: " + Arrays.toString(my_array));
	}

}
