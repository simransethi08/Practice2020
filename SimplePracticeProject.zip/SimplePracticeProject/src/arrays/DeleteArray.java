package arrays;

import java.util.Arrays;

public class DeleteArray {
	// 20. Insert an element in an array at position = x, remaining elements should
	// be pushed to the right

	private static int[] deleteArray(int[] arr, int x) {
		int[] newArr = new int[arr.length - 1];
		for (int i = 0; i < newArr.length; i++) {
			if (i < x - 1) {
				newArr[i] = arr[i];
			} else if (i >= x - 1) {
				newArr[i] = arr[i + 1];
			}
		}
		return newArr;
	}

	public static void main(String[] args) {
		int[] arr = new int[args.length - 1];
		int pos = Integer.parseInt(args[0]);
		int j = 0;
		for (int i = 1; i < args.length; i++) {
			arr[j] = Integer.parseInt(args[i]);
			j++;
		}
		System.out.println("The old array is " + Arrays.toString(arr));
		int[] num = deleteArray(arr, pos);
		System.out.println("The new array is " + Arrays.toString(num));

		
		//new code
		int[] my_array = { 25, 14, 56, 15, 36, 56, 77, 18, 29, 49 };

		System.out.println("Original Array : " + Arrays.toString(my_array));

		// Remove the second element (index->1, value->14) of the array
		int removeIndex = 1;

		for (int i = removeIndex; i < my_array.length - 1; i++) {
			my_array[i] = my_array[i + 1];
		}
		// We cannot alter the size of an array , after the removal, the last and second
		// last element in the array will exist twice
		System.out.println("After removing the second element: " + Arrays.toString(my_array));

	}
}
