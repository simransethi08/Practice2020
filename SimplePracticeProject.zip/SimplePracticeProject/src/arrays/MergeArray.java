package arrays;

public class MergeArray {
	//10. Merge two given arrays starting from specific index��	
	private static char[] mergeArray(char[] a1, char[] a2, int index) {
		char[] mergeResult = new char[a1.length + a2.length];
		System.arraycopy(a1, 0, mergeResult, 0, index);
		System.arraycopy(a2, 0, mergeResult, index, a2.length);
		System.arraycopy(a1, (index), mergeResult, (index + a2.length), (a1.length - index));
		return mergeResult;
	}

	public static void main(String[] args) {
		char[] a1 = { 'a', 'b', 'c', 'd', 'e', 'f' };
		char[] a2 = { '1', '2', '3' };
		int index = Integer.parseInt(args[0]);
		mergeArray(a1, a2, index);
		System.out.println(mergeArray(a1, a2, index));
	}

}
