package assessment;

/* Save this in a file called Main.java to compile and test it */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;
// fetch servers using oldest version of a library
/* DO NOT CHANGE ANYTHING ABOVE THIS LINE */
/* You may add any imports here, if you wish, but only from the 
   standard library */

/* Do not add a namespace declaration */
public class ServerAndLib {
	public static Set<String> processData(ArrayList<String> array) {
		Set<String> retVal = new HashSet<String>();

		Map<String, Map<String, String>> sort = new HashMap<>();
		for (String string : array) {
			String data[] = string.split(",");
			String library = data[1].trim();
			String server = data[0].trim();
			String version = data[2].trim();

			if (sort.containsKey(library)) {
				sort.get(library).put(version, server);
			} else {
				Map<String, String> m = new TreeMap<String, String>();
				m.put(version, server);
				sort.put(library, m);
			}
		}
		for (Map.Entry mapValue : sort.entrySet()) {
			Map<String, String> m = (Map<String, String>) mapValue.getValue();
			if (m.size() > 1) {
				int i=0;
				for (String s : m.keySet()) {
					i++;
				if(i<m.size())
					retVal.add(m.get(s));
				}
			}
		}
		return retVal;
	}

	public static void main(String[] args) {
		ArrayList<String> inputData = new ArrayList<String>();
		String line;
		try {
			Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
			while (in.hasNextLine())
				inputData.add(in.nextLine());
			Set<String> retVal = processData(inputData);
			PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
			for (String str : retVal)
				output.println(str);
			output.close();
		} catch (IOException e) {
			System.out.println("IO error in input.txt or output.txt");
		}
	}
}
