package assessment;

import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.io.*;

public class RegexPattern {
	/* Save this in a file called Main.java to compile and test it */

	/* Do not add a package declaration */

	/*
	 * You may add any imports here, if you wish, but only from the standard library
	 */

	public static int process(String str) {
		int count = 0, sum = 0;
		String pattern = "(_[A-Za-z0-9]*|[A-Za-z]+[\\w]*)";
		Pattern r = Pattern.compile(pattern);
		Matcher m = r.matcher(str);
		while (m.find()) {
			String s = m.group(1);
			if (!s.equals("0")) {
				sum += s.length();
				count++;
			}
		}
		return sum / count;
	}

	public static void main(String[] args) {
		try {
			Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
			String line = in.nextLine().trim();
			int retVal = process(line);
			PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
			output.println("" + retVal);
			output.close();
		} catch (IOException e) {
			System.out.println("IO error in input.txt or output.txt");
		}
	}

}
