package assessment;

import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.function.*;
import java.util.regex.*;
import java.util.stream.*;
import static java.util.stream.Collectors.joining;
import static java.util.stream.Collectors.toList;

class Result {

	/*
	 * Complete the 'simpleCipher' function below.
	 *
	 * The function is expected to return a STRING. The function accepts following
	 * parameters: 1. STRING encrypted 2. INTEGER k
	 */

	public static String simpleCipher(String encrypted, int k) {
		// Write your code here
		char[] ch = encrypted.toCharArray();
		String s = "";
		StringBuilder sb = new StringBuilder();
		for (int i = 0; i < ch.length; i++) {
			int p = ch[i] - k;
			if (p < 0) {
				p = p + 65;
			}
			sb.append((char) p);
		}

		return sb.toString();
	}

}

class Parent1 {

	static String name = "Varun";
	int id = 10;
	static {
		System.out.println("parent class static");
	}
	{
		System.out.println("parent class block");
	}

}

class Child1 extends Parent1 {

	static {
		System.out.println("child class static");
	}
	{
		System.out.println("child class block");
	}

}

public class Solution2 {
	public static void main(String[] args) throws IOException {
		//// BufferedReader bufferedReader = new BufferedReader(new
		//// InputStreamReader(System.in));
		// BufferedWriter bufferedWriter = new BufferedWriter(new
		//// FileWriter(System.getenv("OUTPUT_PATH")));

		// String encrypted = bufferedReader.readLine();

		// int k = Integer.parseInt(bufferedReader.readLine().trim());
		//String result = Result.simpleCipher("CDEF", 2);
		//System.out.println(result);

		System.out.println(Child1.name);
		System.out.println(new Child1().id);
		/*
		 * bufferedWriter.write(result); bufferedWriter.newLine();
		 * 
		 * bufferedReader.close(); bufferedWriter.close();
		 */
	}
}
