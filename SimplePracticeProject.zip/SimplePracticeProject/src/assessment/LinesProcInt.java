package assessment;

/* Save this in a file called Main.java to compile and test it */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;

/* You may add any imports here, if you wish, but only from the 
   standard library */

public class LinesProcInt {
    public static int processData(ArrayList<String> array) {
       Map<Integer, List<Integer>> dept = new TreeMap<Integer, List<Integer>>(Collections.reverseOrder());
		
    	for(String line : array) {
    		String data[] = line.split(",");
    	
    		int keyDept = Integer.parseInt(data[2].trim());
    		int valueSalary = Integer.parseInt(data[3].trim());
    		
    		if(dept.containsKey(keyDept)) {
    			dept.get(keyDept).add(valueSalary);
    		}else {
    			List<Integer> salary = new ArrayList<Integer>();
    			salary.add(valueSalary);
    	 		dept.put(keyDept, salary);
    		}
    	}
    	
    	List<Integer> sortedList = new ArrayList<Integer>();
		sortedList = dept.get(dept.keySet().iterator().next());
		Collections.sort(sortedList);
		return sortedList.get(0);
    }

    public static void main (String[] args) {
        ArrayList<String> inputData = new ArrayList<String>();
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
            while(in.hasNextLine()) {
                String line = in.nextLine().trim();
                if (!line.isEmpty()) // Ignore blank lines
                    inputData.add(line);
            }
            int retVal = processData(inputData);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
            output.println("" + retVal);
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }
}
