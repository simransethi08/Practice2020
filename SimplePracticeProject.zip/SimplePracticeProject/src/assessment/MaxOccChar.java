package assessment;


/* Save this in a file called Main.java to compile and test it */

/* Do not add a package declaration */
import java.util.*;
import java.io.*;

/* You may add any imports here, if you wish, but only from the 
   standard library */
   //maximum occurance of element

public class MaxOccChar {
    public static int process(String str) {
    	char[] arr=new char[53];
    	int count=0;
    	for (char c : str.toCharArray()) {
    		if(c==' ') {
    			arr[53]++;
    		}else if(c>='A' && c<='Z') {
    			arr[c-'A']=(arr[c-'A']==0)?1:++arr[c-'A'];
    		}else if(c>='a' && c<='z') {
    			arr[c-'a'+26]=(arr[c-'a'+26]==0)?1:++arr[c-'a'+26];
    		}
		}
    	for(char ch:arr) {
    		if(count<ch) {
    			count=ch;
    		}
    	}        
        return count;
    }

    public static void main (String[] args) {
        try {
            Scanner in = new Scanner(new BufferedReader(new FileReader("input.txt")));
            String line = in.nextLine().trim();
            int retVal = process(line);
            PrintWriter output = new PrintWriter(new BufferedWriter(new FileWriter("output.txt")));
            output.println("" + retVal);
            output.close();
        } catch (IOException e) {
            System.out.println("IO error in input.txt or output.txt");
        }
    }
}
