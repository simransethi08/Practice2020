public class MainClass {
	 public int solution(int N) {
	        long m = N;
	        long max = N;
	        int res = 0;
	        for(int i =1;i<30;i++) {
	            m=(N>>>i) & 0x3fffffff | (N<<(30-i)& 0x3fffffff);
	            if(m>max) {
	                max=m;
	                res=i;
	            }
	        }
	        return res;
	    }
}