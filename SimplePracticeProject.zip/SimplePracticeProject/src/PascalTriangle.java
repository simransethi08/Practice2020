public class PascalTriangle {

	
	static void printPascal(int n) {

		
		for (int line = 1; line <= n; line++) 
		{ 
		    int a = 1; 
		    for (int i = 1; i <= line; i++)  
		    { 
		   System.out.print(a+"\t");
		    a = a * (line - i) / i;  
		    } 
		 System.out.println(""); 
		} 
	}

	
	public static void main(String args[]) {
		int n = 7;
		printPascal(n);
	}
}
