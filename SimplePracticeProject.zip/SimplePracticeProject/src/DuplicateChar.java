
public class DuplicateChar {
	// 5. Display duplicate characters in a string

	private static String countDuplicateChar(String string) {
		char[] carray = string.toCharArray();
		String temp = "";
		for (int i = 0; i < string.length(); i++) {
			for (int j = i + 1; j < string.length(); j++) {
				if (carray[i] == carray[j]) {
					temp = temp + carray[j];
					break;
				}
			}
		}
		return temp;
	}

	public static void main(String[] args) {
			String dupli = countDuplicateChar(args[0]);
			System.out.println("The duplicate char are : " + dupli);
		
	}
}
