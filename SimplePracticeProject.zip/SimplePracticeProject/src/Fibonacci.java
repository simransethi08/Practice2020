
public class Fibonacci {
	static int a = 0;
	static int b = 1;
	static int sum = 0;

	private static void fibonacci(int n) {
		if (n > 0) {
			sum = a + b;
			a = b;
			b = sum;
			System.out.print(" " + sum);
			fibonacci(n - 1);
		}
	}
	
	private static int difference() {
		int[][] array= {{11,2,4},
						{4,5, 6},
						{10, 8, -12}};
		int sum_a=0,sum_b=0;
        for(int i=0;i<array.length;i++){
        	System.out.println(array[i][i]);
            sum_a=sum_a+array[i][i];
        }
        System.out.println(sum_a);
        int j=array.length-1;
        for(int i=0;i<array.length;i++){
                sum_b=sum_b+array[i][j];
                if(j>=0)
                j--;
        
        }
        System.out.println(sum_b);
        System.out.println(Math.abs(sum_a-sum_b));
    return Math.abs(sum_a-sum_b);
	}

	public static void main(String[] args) {
		//int count = Integer.parseInt(args[0]);
		//System.out.print(a + " " + b);
		difference();
		//fibonacci(count - 2);
	}
}
