import java.util.Arrays;
//2. Find largest number in given array
public class ThirdLargestNum {
	public static int thirdLargest(int[] arr) {
		Arrays.sort(arr);
		return arr[arr.length-3];
	}

	public static void main(String[] args) {
		int[] arr = new int[args.length];
		for (int i = 0; i < args.length; i++) {
			arr[i] = Integer.parseInt(args[i]);
		}
		int num = thirdLargest(arr);
		System.out.println("The third largest number is " + num);
	}

}
