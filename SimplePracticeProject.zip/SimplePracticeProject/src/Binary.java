import java.util.Scanner;

public class Binary {
	//Consecutive 1s in base 2 of integer
	public static int convert(int n) {
		String s = "";
		while (n >= 1) {
			int r = n % 2;
			n = n / 2;
			s = s + r;
		}
		int count = 0;
		char[] ch = s.toCharArray();
		System.out.println(s);
		for (int i = 0; i < ch.length; i++) {
			if (ch[i] == '1') {
				int cur_count = 0;
				while (ch[i] == '1') {
					cur_count++;
					if (i < ch.length - 1)
						i++;
					else
						break;
				}
				if (cur_count > count) {
					count = cur_count;
				}
			}
		}
		return count;
	}

	public static void main(String[] args) {
		// int n = scanner.nextInt();
		// scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
		 System.out.println(convert(439));

		// scanner.close();
	}
}
