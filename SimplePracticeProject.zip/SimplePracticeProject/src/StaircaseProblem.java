
public class StaircaseProblem {

	public static int count(int n, int m) {
		if (n > m) {
			int a = n / 2;
			if (a % m == 0) {
				return a;
			} else
				return a + 1;
		} else
			return -1;
	}

	public static void main(String[] args) {
		int count = count(20, 3);
		System.out.println(count);
	}
}
