import java.util.Arrays;
import java.util.Scanner;

public class CoinProblem {
	public static int count(int n, int[] arr, int sum) {
		int count = 0;
		Arrays.sort(arr);
		for (int i = n - 1; i >= 0; i--) {
			if (arr[i] <= sum) {
				while (sum >= arr[i] && sum - arr[i] >= 0) {
					sum = sum - arr[i];
					System.out.println("sum=" + sum + " arr[i]" + arr[i]);
					count++;
				}
			} else {
				while (arr[i] > sum && i >= 0) {
					break;
				}
			}
		}
		return (sum == 0) ? count : -1;
	}

	public static void main(String[] args) {
		// Scanner in=new Scanner(System.in);
		double no=Math.ceil(1/2);
		System.out.println(no);
		int n = 3;
		int sum = 11;
		// in.nextLine();
		int[] arr = { 1, 3, 5 };
		/*
		 * for(int i=0;i<n;i++){ arr[i]=in.nextInt(); }
		 */
		int count = count(n, arr, sum);
		if (count == -1) {
			System.out.println("Not possible");
		} else
			System.out.println(count);
	}

}
