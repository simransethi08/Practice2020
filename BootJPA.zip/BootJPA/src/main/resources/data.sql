insert into alien values (101,'navin','java');
insert into alien values (102,'sim','dba');
insert into alien values (103,'dim','python');
insert into alien values (104,'anu','sql');
insert into alien values (105,'sheena','android');
