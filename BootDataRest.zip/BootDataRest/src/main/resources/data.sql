insert into alien values (1,'navin','java');
insert into alien values (2,'sim','dba');
insert into alien values (3,'dim','python');
insert into alien values (4,'anu','sql');
insert into alien values (5,'sheena','android');
